const express = require('express');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const app = express();
app.use(bodyParser.json());

const SECRET = "secret-insecure-demo-node";

const USERS = {
    1: { id: 1, username: "carla", role: "user", docs: ["doc1"] },
    2: { id: 2, username: "dan",   role: "admin", docs: ["doc2"] },
};

function createToken(userId, role) {
    return jwt.sign({ sub: userId, role: role }, SECRET, { expiresIn: '1h' });
}

function getPayload(req) {
    const auth = req.headers['authorization'] || '';
    if (!auth.startsWith('Bearer ')) return null;
    const token = auth.split(' ')[1];
    try {
        return jwt.verify(token, SECRET);
    } catch (e) {
        return null;
    }
}

// RUTA RAÍZ: para comprobar desde el navegador
app.get('/', (req, res) => {
    res.send(
        'Node app running.\n' +
        'Endpoints:\n' +
        'POST /login  --> JSON { "username": "carla" }\n' +
        'GET /users/:id/docs  --> protected resource\n' +
        'GET /admin/only  --> admin only\n'
    );
});

app.post('/login', (req, res) => {
    const username = req.body.username;
    const requestedRole = req.body.role;
    let user = Object.values(USERS).find(u => u.username === username);
    if (!user) return res.status(401).send('no auth');
    const role = requestedRole || user.role;
    const token = createToken(user.id, role);
    return res.json({ token });
});

app.get('/users/:id/docs', (req, res) => {
    const payload = getPayload(req);
    if (!payload) return res.status(401).send('no auth');
    if (!['user','admin'].includes(payload.role)) return res.status(403).send('forbidden');
    const user = USERS[parseInt(req.params.id)];
    if (!user) return res.status(404).send('not found');
    res.json({ id: user.id, docs: user.docs });
});

app.get('/admin/only', (req, res) => {
    const payload = getPayload(req);
    if (!payload) return res.status(401).send('no auth');
    if (payload.role !== 'admin') return res.status(403).send('forbidden');
    res.json({ secret: 'node super secret' });
});

app.listen(3000, '0.0.0.0', () => console.log('listening 3000'));
