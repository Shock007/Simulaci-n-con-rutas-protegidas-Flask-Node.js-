from flask import Flask, request, jsonify, abort
import jwt
import datetime

app = Flask(__name__)
SECRET = "secret-insecure-demo"  # NO usar así en producción

# "Base de datos" en memoria
USERS = {
    1: {"id": 1, "username": "alice", "role": "user", "notes": ["nota a"]},
    2: {"id": 2, "username": "bob", "role": "admin", "notes": ["nota b"]},
}

def create_token(user_id, role):
    payload = {
        "sub": user_id,
        "role": role,
        "exp": datetime.datetime.utcnow() + datetime.timedelta(hours=1)
    }
    return jwt.encode(payload, SECRET, algorithm="HS256")

def get_token_payload():
    auth = request.headers.get("Authorization", "")
    if not auth.startswith("Bearer "):
        abort(401)
    token = auth.split()[1]
    try:
        return jwt.decode(token, SECRET, algorithms=["HS256"])
    except jwt.ExpiredSignatureError:
        abort(401)

# RUTA RAÍZ: útil para comprobar desde el navegador
@app.route("/", methods=["GET"])
def index():
    return (
        "Flask app running.\n"
        "Endpoints:\n"
        "POST /login  --> JSON {\"username\":\"alice\"}\n"
        "GET /users/<id>/notes  --> protected resource\n"
        "GET /admin/secret  --> admin only\n"
    ), 200

@app.route("/login", methods=["POST"])
def login():
    data = request.json or {}
    username = data.get("username")
    for u in USERS.values():
        if u["username"] == username:
            requested_role = data.get("role", u["role"])
            token = create_token(u["id"], requested_role)
            # PyJWT puede devolver bytes o str según la versión
            if isinstance(token, bytes):
                token = token.decode()
            return jsonify(token=token)
    return abort(401)

@app.route("/users/<int:user_id>/notes", methods=["GET"])
def get_notes(user_id):
    payload = get_token_payload()
    if payload.get("role") not in ("user", "admin"):
        abort(403)
    user = USERS.get(user_id)
    if not user:
        abort(404)
    return jsonify({"id": user_id, "notes": user["notes"]})

@app.route("/admin/secret", methods=["GET"])
def admin_secret():
    payload = get_token_payload()
    if payload.get("role") != "admin":
        abort(403)
    return jsonify(secret="datos super confidenciales")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

