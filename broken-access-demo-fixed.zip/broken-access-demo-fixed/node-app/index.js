// index.js (Node resource server — no login here)
// expects JWT_SECRET and DATABASE_URL env vars
const express = require('express');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const { Pool } = require('pg');

const app = express();
app.use(bodyParser.json());

const JWT_SECRET = process.env.JWT_SECRET || 'dev-jwt-secret';
const DATABASE_URL = process.env.DATABASE_URL || 'postgresql://postgres:postgres@db:5432/demo';

const pool = new Pool({ connectionString: DATABASE_URL });

async function isTokenRevoked(jti) {
    const r = await pool.query('SELECT jti FROM revoked_tokens WHERE jti=$1', [jti]);
    return r.rowCount > 0;
}

function tokenFromHeader(req) {
    const auth = req.headers['authorization'] || '';
    if (!auth.startsWith('Bearer ')) return null;
    return auth.split(' ')[1];
}

async function verifyToken(req, res, next) {
    const token = tokenFromHeader(req);
    if (!token) return res.status(401).json({ error: 'no token' });
    let payload;
    try {
        payload = jwt.verify(token, JWT_SECRET);
    } catch (e) {
        return res.status(401).json({ error: 'invalid token' });
    }
    // check jti not revoked
    if (await isTokenRevoked(payload.jti)) return res.status(401).json({ error: 'token revoked' });
    // verify user exists and role matches DB
    const { rows } = await pool.query('SELECT id, role FROM users WHERE id=$1', [payload.sub]);
    if (rows.length === 0) return res.status(401).json({ error: 'unknown user' });
    if (rows[0].role !== payload.role) return res.status(401).json({ error: 'role mismatch' });
    req.userPayload = payload;
    next();
}

app.get('/users/:id/docs', verifyToken, async (req, res) => {
    const payload = req.userPayload;
    const requestedId = parseInt(req.params.id, 10);
    const { rows } = await pool.query('SELECT id, role, notes FROM users WHERE id=$1', [requestedId]);
    if (rows.length === 0) return res.status(404).json({ error: 'not found' });
    // owner or admin only
    const requester = (await pool.query('SELECT id, role FROM users WHERE id=$1', [payload.sub])).rows[0];
    if (!requester) return res.status(401).json({ error: 'unauth' });
    if (requester.role !== 'admin' && requester.id !== requestedId) return res.status(403).json({ error: 'forbidden' });
    return res.json({ id: rows[0].id, docs: rows[0].notes });
});

app.get('/admin/only', verifyToken, async (req, res) => {
    const payload = req.userPayload;
    const requester = (await pool.query('SELECT role FROM users WHERE id=$1', [payload.sub])).rows[0];
    if (!requester || requester.role !== 'admin') return res.status(403).json({ error: 'forbidden' });
    return res.json({ secret: 'node super secret (admin only)' });
});

app.listen(3000, '0.0.0.0', () => console.log('node app listening 3000'));

