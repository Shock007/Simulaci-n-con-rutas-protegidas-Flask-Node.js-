# app.py (Flask auth + resource server) - CORRECCIÓN SQLALCHEMY row._mapping
import os, uuid, datetime
from functools import wraps
from flask import Flask, request, jsonify, abort, g
import jwt
from werkzeug.security import check_password_hash
from sqlalchemy import create_engine, Column, Integer, Text, JSON, Table, MetaData, select
from sqlalchemy.orm import registry, Session

DATABASE_URL = os.environ.get("DATABASE_URL", "postgresql://postgres:postgres@db:5432/demo")
JWT_SECRET = os.environ.get("JWT_SECRET", "dev-jwt-secret")
JWT_ALGORITHM = "HS256"
ACCESS_EXPIRES_MINUTES = 60

app = Flask(__name__)

# SQLAlchemy minimal mapping
engine = create_engine(DATABASE_URL, future=True)
mapper_registry = registry()
metadata = MetaData()

users_table = Table(
    "users", metadata,
    Column("id", Integer, primary_key=True),
    Column("username", Text, unique=True),
    Column("password_hash", Text),
    Column("role", Text),
    Column("notes", JSON),
)

revoked_table = Table(
    "revoked_tokens", metadata,
    Column("jti", Text, primary_key=True),
    Column("revoked_at", Text)
)

def get_db_session():
    return Session(engine)

def create_access_token(user_id, role):
    jti = str(uuid.uuid4())
    payload = {
        "sub": user_id,
        "role": role,
        "jti": jti,
        "exp": datetime.datetime.utcnow() + datetime.timedelta(minutes=ACCESS_EXPIRES_MINUTES),
        "iat": datetime.datetime.utcnow()
    }
    token = jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)
    return token, jti

def token_from_header():
    auth = request.headers.get("Authorization","")
    if not auth.startswith("Bearer "):
        return None
    return auth.split(" ",1)[1]

def verify_token_and_get_payload(token):
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
    except Exception:
        return None
    # check jti not revoked and role matches DB
    with get_db_session() as s:
        # revocation check
        row = s.execute(select(revoked_table.c.jti).where(revoked_table.c.jti==payload.get("jti"))).first()
        if row:
            return None
        # ensure user exists and role matches DB
        uid = payload.get("sub")
        user_row = s.execute(select(users_table).where(users_table.c.id==uid)).first()
        if not user_row:
            return None
        # acceder mediante _mapping para compatibilidad 2.x
        db_role = user_row._mapping.get("role")
        if payload.get("role") != db_role:
            return None
    return payload

def auth_required(fn):
    @wraps(fn)
    def inner(*a, **kw):
        token = token_from_header()
        payload = verify_token_and_get_payload(token)
        if not payload:
            abort(401)
        g.current_user = payload
        g._raw_token = token
        return fn(*a, **kw)
    return inner

@app.route("/login", methods=["POST"])
def login():
    data = request.json or {}
    username = data.get("username")
    password = data.get("password")
    if not username or not password:
        return jsonify({"error":"username and password required"}), 400
    try:
        with get_db_session() as s:
            row = s.execute(select(users_table).where(users_table.c.username==username)).first()
            if not row:
                return jsonify({"error":"invalid credentials"}), 401
            # usar _mapping para extraer columnas
            pwd_hash = row._mapping.get("password_hash")
            if not pwd_hash or not check_password_hash(pwd_hash, password):
                return jsonify({"error":"invalid credentials"}), 401
            uid = row._mapping.get("id")
            role = row._mapping.get("role")
            token, jti = create_access_token(uid, role)
            return jsonify({"access_token": token})
    except Exception:
        app.logger.exception("Error en login")
        return jsonify({"error":"internal error"}), 500

@app.route("/logout", methods=["POST"])
@auth_required
def logout():
    token = g._raw_token
    payload = g.current_user
    jti = payload.get("jti")
    if not jti:
        abort(400)
    with get_db_session() as s:
        s.execute(revoked_table.insert().values(jti=jti))
        s.commit()
    return jsonify({"msg":"token revoked"}), 200

@app.route("/users/<int:user_id>/notes", methods=["GET"])
@auth_required
def get_notes(user_id):
    payload = g.current_user
    with get_db_session() as s:
        user_row = s.execute(select(users_table).where(users_table.c.id==user_id)).first()
        if not user_row:
            abort(404)
        requester_id = payload.get("sub")
        requester_row = s.execute(select(users_table).where(users_table.c.id==requester_id)).first()
        if not requester_row:
            abort(401)
        requester_role = requester_row._mapping.get("role")
        if requester_role != "admin" and requester_id != user_id:
            abort(403)
        notes = user_row._mapping.get("notes")
        return jsonify({"id": user_id, "notes": notes})

@app.route("/admin/secret", methods=["GET"])
@auth_required
def admin_secret():
    payload = g.current_user
    with get_db_session() as s:
        requester_row = s.execute(select(users_table).where(users_table.c.id==payload.get("sub"))).first()
        if not requester_row or requester_row._mapping.get("role") != "admin":
            abort(403)
    return jsonify({"secret":"datos super confidenciales (solo admin)"}), 200

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
