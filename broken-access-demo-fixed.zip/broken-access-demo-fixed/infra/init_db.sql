-- init_db.sql
CREATE DATABASE demo;
\connect demo

CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL,
  notes JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE revoked_tokens (
  jti TEXT PRIMARY KEY,
  revoked_at TIMESTAMPTZ DEFAULT now()
);

-- usuarios semilla (passwords: alicepass, bobpass, carlapass, danpass)
INSERT INTO users (username, password_hash, role, notes) VALUES
('alice', 'pbkdf2:sha256:1000000$kSv3GOlv$567ffbfbe4c3ca8c14d1d97a607e4de3b7eace72ecd31012c3b1cc6b51f0bb4c', 'user', '["nota a"]'),
('bob',   'pbkdf2:sha256:1000000$EZIKLhZW$effc580541fb544b74a324c0369c72bd59f764976e0c8c76407a45d91eda716a', 'admin', '["nota b"]'),
('carla', 'pbkdf2:sha256:1000000$cx9A6zgc$23990510927c087573bc33372b3009aefcac6f4695400fcc74b3d35263aa11ce', 'user', '["doc1"]'),
('dan',   'pbkdf2:sha256:1000000$iCwxZrsS$ba1ef52d15d9307b84ce373f15139ed7ba484a901a483512135751f5226a8221', 'admin', '["doc2"]');

